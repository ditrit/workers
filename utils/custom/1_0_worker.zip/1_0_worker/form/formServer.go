package form

import (
	"log"
	"net/http"

	goclient "github.com/ditrit/gandalf-libraries-goclient"

	"github.com/go-chi/chi"
	goformit "github.com/kirves/go-form-it"
)

const (
	server_address = "localhost"
	server_port    = ":3010"
)

type FormServer struct {
	address    string
	port       string
	router     *chi.Mux
	controller *FormController
	form       *goformit.Form
	Rooturl    string
	Url        string
}

func NewFormServer(uuid string, payload FormPayload, clientGandalf *goclient.ClientGandalf) *FormServer {
	formServer := new(FormServer)
	formServer.address = server_address
	formServer.port = server_port
	formServer.Rooturl = server_address + server_port

	formServer.Url = ReturnHashURLS()

	formServer.form = CreateFormWithUrl(formServer.Url, uuid, payload.Fields)

	formServer.controller = NewFormController(formServer.form, clientGandalf)
	//formServer.router = GetRouter(formServer.controller)

	formServer.router = GetRouterWithUrl(formServer.Url, formServer.controller)

	return formServer
}

func (f FormServer) Run() {
	// Start the server
	log.Printf("Listening on localhost: %s", f.port)
	log.Println(http.ListenAndServe(f.Rooturl, f.router))
}
