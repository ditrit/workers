package form

type FormPayload struct {
	Fields []Field
}
